<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
</head>
<body>
    <form method="post" action="">
        

    </form>
    
</body>
</html><?php /**PATH C:\xampp\htdocs\Laravel projects\crud\resources\views/create.blade.php ENDPATH**/ ?>