<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
</head>
<body>
    <form method="post" action="<?php echo e(route('crud.store')); ?>">
        <?php echo csrf_field(); ?>
        <button type="submit">Add new</button><br>
        <input type="text" id="child_first_name" name="child_first_name" placeholder="Child First Name" required>
        <?php $__errorArgs = ['child_first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <input type="text" id="child_middle_name" name="child_middle_name" placeholder="Child Middle Name"required>
        <?php $__errorArgs = ['child_middle_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <input type="text" id="child_last_name" name="child_last_name" placeholder="Child Last Name"required>
        <?php $__errorArgs = ['child_last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <input type="number" id="child_age" name="child_age" placeholder="Child Age"required>
        <?php $__errorArgs = ['child_age'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <select id="gender" name="gender" placeholder="Gender">
            <option disabled selected>Select Gender</option>
            <option value="Male">Male</option>
            <option value="Femal">Female</option>
            <option value="Other">Other</option>
        </select>
        <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <label for="different_address">Different address?</label>
        <input type="checkbox" id="different_address" name="different_address">
        <input type="text" id="child_address" name="child_address" placeholder="child address" disabled required>
        <?php $__errorArgs = ['child_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <input type="text" id="child_city" name="child_city" placeholder="Child City" disabled required>
        <?php $__errorArgs = ['child_city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <input type="text" id="child_state" name="child_state" placeholder="Child State" disabled required>
        <?php $__errorArgs = ['child_state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <select  id="country" name="country" disabled>
            <option value="United States" selected>United States</option>
            <option value="Nepal">Nepal</option>
            <option value="India">India</option>
            <option value="China">China</option>
            <option value="France">France</option>
            <option value="United Kingdom" >United Kingdom</option>
        </select>
        <input type="number" id="child_zip" name="child_zip" placeholder="Child Zip Code" disabled required>
        <?php $__errorArgs = ['child_zip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </form>

    <table border="1">
        <tr>
            <td>Delete</td>
            <td>Child First Name</td>
            <td>Child Middle Name</td>
            <td>Child Last Name</td>
            <td>Child Age</td>
            <td>Child Gender</td>
            <td>Child Address</td>
            <td>Child City</td>
            <td>Child State</td>
            <td>Country</td>
            <td>Child Zip Address</td>
        </tr>
        
            <?php
                use App\Models\Crud;
                use App\Http\Controllers\resourceController;
                $data =  Crud::all();
            ?>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $database): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <Form method="post"  action=" <?php echo e(route('crud.destroy',[ $database->id] )); ?>" >
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        
                        <button type="submit">Delete</button><br>
                    </Form>
                </td>
                <td><?php echo e($database->child_first_name); ?></td>
                <td><?php echo e($database->child_middle_name); ?></td>
                <td><?php echo e($database->child_last_name); ?></td>
                <td><?php echo e($database->child_age); ?></td>
                <td><?php echo e($database->gender); ?></td>
                <td><?php echo e($database->child_address); ?></td>
                <td><?php echo e($database->child_city); ?></td>
                <td><?php echo e($database->child_state); ?></td>
                <td><?php echo e($database->country); ?></td>
                <td><?php echo e($database->child_zip); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </table>

        <script>
            document.getElementById('different_address').onchange = function() {
            document.getElementById('child_address').disabled = !this.checked;
            document.getElementById('child_city').disabled = !this.checked;
            document.getElementById('child_state').disabled = !this.checked;
            document.getElementById('country').disabled = !this.checked;
            document.getElementById('child_zip').disabled = !this.checked;
            };
        </script>
    
</body>
</html><?php /**PATH C:\xampp\htdocs\Laravel projects\crud\resources\views/index.blade.php ENDPATH**/ ?>